const express=require('express');
const cors=require('cors');
const mongoose=require('mongoose');
const app=express();
require('./db/conn.js');
const students=require('./models/students.js');
const port=process.env.PORT || 8000;
app.use(cors());
app.use(express.json());

//Post route
app.post('/insert',async(req,res)=>{

    const name=req.body.name;
    const email=req.body.email;
    const food= new students({name: name, email: email});
    try{
        await food.save();
        res.send('Data inserted');
    }catch (err){
        console.log(err);

    }
});

//
//Get route
app.get('/read',async(req,res)=>{
    students.find({},(err,result)=>{
        if(err){
            res.send(err);
        }
        res.send(result);
    });
   
});

//
//Update Code  in this section i have the probleum
app.put('/update',async(req,res)=>{

    const newName=req.body.newName;
    const newEmail=req.body.newEmail;
    const id=req.body.id;
    
    try{
       await students.findById(id,(err,updatedFood)=>{
          updatedFood.name=newName,
           updatedFood.email=newEmail,
           updatedFood.save();
           res.send("update"); 
       })
    }catch (err){
        console.log(err);
    }
});


//
//
app.delete('/delete/:id',async(req,res)=>{
    const id=req.params.id;
    await students.findByIdAndRemove(id).exec();
    res.send("deleted");
});

//
app.listen(port,()=>{console.log(`The serrver is running at ${port}`)});
