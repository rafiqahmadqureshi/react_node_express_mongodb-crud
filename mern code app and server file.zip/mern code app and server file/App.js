import React,{useState,useEffect} from 'react' ;
import Axios from 'axios';

import './App.css';

function App() {

  //For Insert
  const [name,setName]=useState("");
  const [email,setEmail]=useState("");
  //For Update
  const [newName,setNewName]=useState("");
  const [newEmail,setNewEmail]=useState("");
  //
  const insert=()=>{
    //console.log(foodName + days);
    Axios.post("http://localhost:8000/insert",{
      name:name,
      email:email,
    
    });
  };
  //Read the content from the data base
const [studentDetails,setStudentDetails]=useState([]);

useEffect(()=>{
  Axios.get("http://localhost:8000/read").then((response)=>{
    setStudentDetails(response.data);

  })
},[]);
//
//UpdateCode
const update=(id)=>{
  Axios.put("http://localhost:8000/update",{
    id:id,
    newName:newName,
    newEmail:newEmail,
  })
}
//
//Delete Code
const deleteStudent=(id)=>{
  Axios.delete(`http://localhost:8000/delete/${id}`,{
    id:id,
    newName:newName,
  });

 };

//

  return (
    <div className="App">
      <h1>App Component</h1>
      <input type="text"       
      onChange={(event)=>{
        setName(event.target.value);
      }}
      />
      <input type="text"   
     onChange={(e)=>{
       setEmail(e.target.value);
      }}     
     />
      <button onClick={insert}>Insert Data</button>
      <h1>Food List</h1>
     {studentDetails.map((val,key)=>{
       return(
       <div key={key} className="food">
        
        <input type="text" placeholder={val.name}
         onChange={(e)=>{
          setNewName(e.target.value);
         }}
         />
          <input type="text" placeholder={val.email}
         onChange={(e)=>{
        setNewEmail(e.target.value);
         }}
         />
    
    <button onClick={()=>update(val._id)}>Update</button>
    <button onClick={()=>deleteStudent(val._id)}>Delete</button>  
        

       </div>
       );
     })}
    </div>
  );
}

export default App;